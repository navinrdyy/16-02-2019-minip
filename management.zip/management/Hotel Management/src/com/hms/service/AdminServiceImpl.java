package com.hms.service;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.hms.bean.BookingBean;
import com.hms.bean.HotelBean;
import com.hms.bean.RoomBean;
import com.hms.dao.DaoImpl;
import com.hms.dao.IDao;

public class AdminServiceImpl implements IService {
	IDao idaoobj = null;
	@Override
	public boolean adminValidation(String uName, String pass) {
		if(uName.equals("admin") && pass.equals("admin")) {
			return true;
			}
		else {
			System.out.println("Invalid Credentials");
			System.out.println("Please enter again");
			return false;
			}
	}

	@Override
	public List<HotelBean> getAllHotels() throws SQLException {
		idaoobj = new DaoImpl();
		return idaoobj.getAllHotels();
	}

	@Override
	public List<RoomBean> getAllRooms(String hid) throws SQLException {
		idaoobj = new DaoImpl();
		return idaoobj.getAllRooms(hid);
	}

	@Override
	public int addHotel(HotelBean hBean) throws SQLException {
		idaoobj = new DaoImpl();
		return idaoobj.addHotel(hBean);
	}

	@Override
	public HotelBean getHotelById(String htid) throws SQLException {
		idaoobj = new DaoImpl();
		return idaoobj.getHotelById(htid);
	}

	@Override
	public int updateCity(String city1, String htid) throws SQLException {
		idaoobj = new DaoImpl();
		return idaoobj.updateCity(city1,htid);
	}

	@Override
	public List<BookingBean> getHotelDetails(String hotelId) throws SQLException {
		idaoobj = new DaoImpl();
		return idaoobj.getHotelDetails(hotelId);
	}

	@Override
	public List<BookingBean> getDetailsByDate(String bdate) throws ParseException {
		idaoobj = new DaoImpl();
		return idaoobj.getDetailsByDate(bdate);
	}

	@Override
	public int radddetails(RoomBean rbean) throws SQLException {
		idaoobj = new DaoImpl();
		return idaoobj.raddadetails(rbean);
	}

	@Override
	public int deleteroom(String rid1) {
		idaoobj = new DaoImpl();
		return idaoobj.deleteroom(rid1);
	}

	@Override
	public int updateRoomNumber(String rnum, String rid2) throws SQLException {
		idaoobj = new DaoImpl();
		return idaoobj. updateRoomNumber(rnum,rid2);
	}

	@Override
	public int updateName(String hname, String htid) {
		idaoobj = new DaoImpl();
		return idaoobj. updateName(hname,htid);
	}

	@Override
	public int updateAddress(String haddress, String htid) {
		idaoobj = new DaoImpl();
		return idaoobj. updateAddress(haddress,htid);
	}

	@Override
	public int updateDesc(String hdesc, String htid) {
		idaoobj = new DaoImpl();
		return idaoobj.updateDesc(hdesc,htid);
	}

	@Override
	public int updateRpn(String hrpn, String htid) {
		idaoobj = new DaoImpl();
		return idaoobj.updateRpn(hrpn,htid);
	}

	@Override
	public int updatepn1(String hpn1, String htid) {
		idaoobj = new DaoImpl();
		return idaoobj.updatepn1(hpn1,htid);
	}

	public boolean hotelVal(String hid) {
		
		Pattern pat = Pattern.compile("[h][0-9]{3}");
		Matcher mat = pat.matcher(hid);
		if (mat.matches()){
			return true;
		}
		else {
			System.out.println("Inavalid Hotel Id \nPlease Reenter");
			return false;
			
		}
		
		
		
		
		
	}

	public boolean cityVal(String city) {
		
		Pattern pat = Pattern.compile("[A-Z][a-z]{2,15}");
		Matcher mat = pat.matcher(city);
		if (mat.matches()){
			return true;
		}
		else {
			System.out.println("Inavalid City \nPlease Reenter");
			return false;
		}
}

	public boolean nameVal(String hName) {
		
		Pattern pat = Pattern.compile("[A-Z][a-z]{2,20}");
		Matcher mat = pat.matcher(hName);
		if (mat.matches()){
			return true;
		}
		else {
			System.out.println("Inavalid Hotel Name \nPlease Reenter");
			return false;
		}
	}

	public boolean mnoVal(String phone1) {
		Pattern pat = Pattern.compile("[7-9][0-9]{9}");
		Matcher mat = pat.matcher(phone1);
		if (mat.matches()){
			return true;
		}
		else {
			System.out.println("Inavalid Mobile \nPlease Reenter");
			return false;
		}
	}

	public boolean emailVal(String email) {
		Pattern pat = Pattern.compile("[a-zA-z0-9/_.%+-]+@[a-zA-z]+.[a-zA-Z]{2,20}$");
		//System.out.println(email);
		//Pattern pat = Pattern.compile("[A-Z]{2,3}");
		Matcher mat = pat.matcher(email);
		//System.out.println("fd"+email);
		
		if (mat.matches()){
			return true;
		}
		else {
			System.out.println("Inavalid Email....... \nPlease Reenter");
			return false;
		}
	}

	public boolean rateVal(String rate) {
		Pattern pat = Pattern.compile("[0-9]{1,10}");
		Matcher mat = pat.matcher(rate);
		if (mat.matches()){
			return true;
		}
		else {
			System.out.println("Inavalid City \nPlease Reenter");
			return false;
		}
	}

	public boolean dateVal(String bdate) {
		
		Pattern pat = Pattern.compile("[0-3][0-9][-][A-Za-z]{3}[-][0-9]{4}");
		Matcher mat = pat.matcher(bdate);
		if (mat.matches()){
			return true;
		}
		else {
			System.out.println("Inavalid Date \nPlease Reenter");
			return false;
		}
	}
}