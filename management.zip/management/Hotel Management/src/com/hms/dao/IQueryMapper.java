package com.hms.dao;

public interface IQueryMapper {
	
	public static final String 	GET_ALL_HOTELS= "Select * from hotel";
	public static final String 	GET_ALL_ROOMS="Select * from roomdetails where hotel_id=?";
	public static final String ADD_HOTELS = "insert into hotel values(?,?,?,?,?,?,?,?,?,?,?)";
	public static final String FIND_HOTEL ="select * from hotel where hotel_id=?";
	public static final String UPDATE_CITY ="UPDATE hotel SET city=? where hotel_id=?";
	public static final String UPDATE_HOTEL_NAME = "UPDATE hotel SET hotel_name=? where hotel_id=?";
	public static final String UPDATE_HOTEL_ADDRESS = "UPDATE hotel SET address=? where hotel_id=?";
	public static final String UPDATE_HOTEL_DESC = "UPDATE hotel SET description=? where hotel_id=?";
	public static final String UPDATE_HOTEL_RPN ="UPDATE hotel SET  AVG_RATE_PERNIGHT=? where hotel_id=?";
	public static final String hotel_detail ="select * from bookingdetails where hotel_id=?";
	public static final String get_by_date = "select * from  bookingdetails where BOOKED_FROM=?";
	public static final String ADD_ROOMS = "insert into roomdetails values(?,?,?,?,?,?)";
	public static final String DEL_ROOMS = "delete from roomdetails where room_id=?";
	public static final String UPDATE_ROOM_NUM = "UPDATE roomdetails SET room_no=? where room_id=?";
	public static final String UPDATE_HOTEL_PN1 ="UPDATE hotel SET  PHONE_NO1=? where hotel_id=?";

	
	
	

}
