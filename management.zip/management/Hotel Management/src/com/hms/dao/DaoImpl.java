package com.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.hms.bean.BookingBean;
import com.hms.bean.HotelBean;
import com.hms.bean.RoomBean;
import com.hms.util.DbUtil;

public class DaoImpl implements IDao{
	Connection conn = null;
	int status;
	int status1=0;
	int status2=0;
	@Override
	public List<HotelBean> getAllHotels() throws SQLException {
		conn = DbUtil.getDbConnection();
		List<HotelBean> hList = null;
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery(IQueryMapper.GET_ALL_HOTELS);
		hList = new ArrayList();
		HotelBean hbean=null;
		while(rs.next()) {
			hbean=new HotelBean(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),
				rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10),rs.getString(11));
			hList.add(hbean);
			
	}
		return hList;
	}
	@Override
	public List<RoomBean> getAllRooms(String hid) throws SQLException {
		conn = DbUtil.getDbConnection();
		PreparedStatement pst = conn.prepareStatement(IQueryMapper.GET_ALL_ROOMS);
		pst.setString(1, hid);
		ResultSet rs = pst.executeQuery();
		List<RoomBean> rList = null;
		rList = new ArrayList();
		RoomBean rbean = null;
		while(rs.next()) {
			rbean = new RoomBean(rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getString(6));
			rList.add(rbean);
			
	}
		return rList;
	}
	@Override
	public int addHotel(HotelBean hBean) throws SQLException {
		conn = DbUtil.getDbConnection();
		PreparedStatement pst = conn.prepareStatement(IQueryMapper.ADD_HOTELS);
		pst.setString(1, hBean.getHotel_id());
		pst.setString(2, hBean.getCity());
		pst.setString(3, hBean.getHotel_name());
		pst.setString(4, hBean.getAddress());
		pst.setString(5, hBean.getDescription());
		pst.setString(6, hBean.getAvg_rate_per_night());
		pst.setString(7, hBean.getPhone_no1());
		pst.setString(8, hBean.getPhone_no2());
		pst.setString(9, hBean.getRating());
		pst.setString(10, hBean.getEmail());
		pst.setString(11, hBean.getFax());
		status=pst.executeUpdate();
		return status;
	}
	@Override
	public HotelBean getHotelById(String htid) throws SQLException {
		conn = DbUtil.getDbConnection();
		PreparedStatement pst = conn.prepareStatement(IQueryMapper.FIND_HOTEL);
		pst.setString(1, htid);
		HotelBean hbean=null;
		ResultSet rs = pst.executeQuery();
		while(rs.next()) {
			hbean=new HotelBean(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),
						rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10),rs.getString(11));
		}
		return hbean;
	}
	@Override
	public int updateCity(String city1, String htid) throws SQLException {
		conn = DbUtil.getDbConnection();
		PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_CITY);
		pst.setString(1, city1);
		pst.setString(2, htid);
		//HotelBean hbean=null;
		int result = pst.executeUpdate();
		
		return result;
		
	}
	@Override
	public List<BookingBean> getHotelDetails(String hotelId) throws SQLException {
		conn = DbUtil.getDbConnection();
		BookingBean Bbean=null;
		List<BookingBean> bList1 = null;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.hotel_detail);
			pst.setString(1,hotelId);
			bList1= new ArrayList<>();
			ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				System.out.println("hbd");
				Bbean = new BookingBean(rs.getString(1),rs.getString(2),rs.getString(3),rs.getDate(4),rs.getDate(5),rs.getInt(6),
						rs.getInt(7),rs.getInt(8),rs.getString(9));
				bList1.add(Bbean);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bList1;
	}
	@Override
	public List<BookingBean> getDetailsByDate(String bdate) throws ParseException {
		conn = DbUtil.getDbConnection();
		//SimpleDateFormat sp = null;
		//System.out.println(bdate);
		//SimpleDateFormat formatter2=new SimpleDateFormat("dd-MM-yyyy");  
		//Date date = formatter2.parse(bdate);
		//java.sql.Date datesq = new java.sql.Date(date.getTime());
		//System.out.println("DAte Sq is "+datesq);
		List<BookingBean> bList = null;
		try {
			
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.get_by_date);
			pst.setString(1, bdate);
			ResultSet rs = pst.executeQuery();
			bList = new ArrayList();
			BookingBean bbean=null;
			while(rs.next()) {
				bbean=new BookingBean(rs.getString(1),rs.getString(2),rs.getString(3),rs.getDate(4),rs.getDate(5),rs.getInt(6),
						rs.getInt(7),rs.getInt(8),rs.getString(9));
				bList.add(bbean);
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return bList;
	}
	@Override
	public int raddadetails(RoomBean rbean) throws SQLException {
		// TODO Auto-generated method stub
		conn = DbUtil.getDbConnection();
		try {
			PreparedStatement pst1 = conn.prepareStatement(IQueryMapper.ADD_ROOMS);
			pst1.setString(1,rbean.getHotelId());
			pst1.setString(2,rbean.getRoomId());
			pst1.setString(3,rbean.getRoomNo());
			pst1.setString(4,rbean.getRoomType());
			pst1.setInt(5,rbean.getPricePerNight());
			pst1.setString(6,rbean.getAvailability());
			status1=pst1.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status1;
	}
	@Override
	public int deleteroom(String rid1) {
		conn = DbUtil.getDbConnection();
		try {
			PreparedStatement pst2 = conn.prepareStatement(IQueryMapper.DEL_ROOMS);
			pst2.setString(1,rid1);
			status2=pst2.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status2;
	}
	@Override
	public int updateRoomNumber(String rnum, String rid2) throws SQLException {
		conn = DbUtil.getDbConnection();
		PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_ROOM_NUM);
		pst.setString(1, rnum);
		pst.setString(2, rid2);
		HotelBean hbean5=null;
		int result = pst.executeUpdate();
		if (result>0) {
			
		}
		
		return result;
		
	}
	@Override
	public int updateName(String hname, String htid) {
		conn = DbUtil.getDbConnection();
		int result2=0;;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_HOTEL_NAME);
			pst.setString(1,hname);
			pst.setString(2,htid);
			HotelBean hbean6=null;
			result2= pst.executeUpdate();
			if (result2>0) {
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result2;
	}
	@Override
	public int updateAddress(String haddress, String htid) {
		conn = DbUtil.getDbConnection();
		int result3=0;;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_HOTEL_ADDRESS);
			pst.setString(1,haddress);
			pst.setString(2,htid);
			HotelBean hbean6=null;
			result3= pst.executeUpdate();
			if (result3>0) {
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result3;
	}
	@Override
	public int updateDesc(String hdesc, String htid) {
		conn = DbUtil.getDbConnection();
		int result4=0;;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_HOTEL_DESC);
			pst.setString(1,hdesc);
			pst.setString(2,htid);
			HotelBean hbean6=null;
			result4= pst.executeUpdate();
			if (result4>0) {
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result4;
	}
	@Override
	public int updateRpn(String hrpn, String htid) {
		conn = DbUtil.getDbConnection();
		int result5=0;;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_HOTEL_RPN);
			pst.setString(1,hrpn);
			pst.setString(2,htid);
			HotelBean hbean6=null;
			result5= pst.executeUpdate();
			if (result5>0) {
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result5;

	}
	@Override
	public int updatepn1(String hpn1, String htid) {
		conn = DbUtil.getDbConnection();
		int result5=0;;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.UPDATE_HOTEL_PN1);
			pst.setString(1,hpn1);
			pst.setString(2,htid);
			HotelBean hbean6=null;
			result5= pst.executeUpdate();
			if (result5>0) {
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result5;
	}
}
